腾讯云提供的cmq python sdk没有分发包，因此稍作修改，增加打包部分

使用方法：下载之后解压然后执行下面的命令

```bash
python setup.py install
```
